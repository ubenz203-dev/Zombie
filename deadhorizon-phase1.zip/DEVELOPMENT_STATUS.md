# Development status

**Phase 1: code written, NOT yet built or tested.** No Godot/Android toolchain was available
when this was authored. First CI run may surface script or export errors; fix those before testing.

## Implemented (untested)
Menu, world, FPP controller + arms, touch controls, HUD, zombie AI, graphics settings, CI workflow.

## Known limitations
- No pathfinding: zombies steer straight and slide on walls; can get stuck behind buildings.
- No doors/windows (doorways are open gaps), no day/night, no audio, no real models/textures.
- Graphics menu lacks AO/reflections/shader tiers (Phase 7).
- Attack is a basic fist hit (real combat is Phase 3).
- Crouch, flashlight, interaction, map/inventory/crafting buttons come in later phases.

## Phase checklist
- [ ] Phase 1 approved by user
