extends SceneTree
## Headless smoke test: godot --headless --path . -s tests/smoke_test.gd
## Loads the game scene, runs some frames, checks player + zombie spawning. Exit code 1 on failure.

var _frames := 0
var _game: Node


func _initialize() -> void:
    var packed: PackedScene = load("res://scenes/game.tscn")
    _game = packed.instantiate()
    root.add_child(_game)


func _process(_delta: float) -> bool:
    _frames += 1
    if _frames < 120:
        return false
    var active := 0
    for z in get_nodes_in_group("zombies"):
        if z.active:
            active += 1
    var players := get_nodes_in_group("player").size()
    print("SMOKE: players=%d active_zombies=%d" % [players, active])
    if players == 1 and active > 0:
        print("SMOKE: PASS")
        quit(0)
    else:
        printerr("SMOKE: FAIL")
        quit(1)
    return true
