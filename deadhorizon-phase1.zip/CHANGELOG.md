# Changelog

## 0.1.0 - Phase 1 (first playable prototype)
- Godot 4.3 project, Android ARM64 debug export preset, GitHub Actions APK workflow.
- Main menu, New Game, Settings, pause/death screens.
- Procedural test town (roads, enterable buildings, cars, trees), overcast lighting.
- First-person controller with visible arms, floating joystick, look drag, HIT/JUMP/RUN buttons.
- Survival HUD (health, hunger, thirst, stamina, rest, clock, compass, quick slots).
- Pooled zombies: idle/wander/chase/search/attack/die, sight + hearing, 3 variants.
- Graphics presets (Very Low..Ultra) + custom options, saved with ConfigFile.
