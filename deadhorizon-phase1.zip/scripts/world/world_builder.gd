extends Node3D
## Procedural Phase 1 test town: ground, crossing roads, enterable buildings, cars, trees.
## Placeholder art (flat-colour boxes); real modular assets arrive in Phase 5.

const HALF := 90.0

var building_rects: Array[Rect2] = []

var _rng := RandomNumberGenerator.new()
var _mats := {}


func build() -> void:
    _rng.seed = 1337
    _ground()
    _roads()
    # North of the main road: doors face south (toward the road).
    _building(-22, -14, 12, 10, 3.2, Color(0.55, 0.5, 0.42), true)
    _building(22, -14, 12, 10, 3.2, Color(0.5, 0.42, 0.4), true)
    _building(-48, -14, 14, 10, 3.2, Color(0.45, 0.5, 0.5), true)
    _building(48, -14, 14, 10, 3.2, Color(0.55, 0.45, 0.35), true)
    _building(-22, -38, 12, 10, 3.2, Color(0.5, 0.5, 0.45), true)
    _building(22, -38, 12, 10, 3.2, Color(0.42, 0.45, 0.5), true)
    # South of the main road: doors face north.
    _building(-22, 14, 12, 10, 3.2, Color(0.5, 0.45, 0.4), false)
    _building(22, 14, 12, 10, 3.2, Color(0.55, 0.52, 0.45), false)
    _building(-48, 14, 14, 10, 3.2, Color(0.45, 0.42, 0.45), false)
    _building(48, 14, 14, 10, 3.2, Color(0.5, 0.5, 0.42), false)
    # Supermarket (bigger, taller).
    _building(-45, 42, 24, 14, 4.2, Color(0.6, 0.6, 0.58), false)
    _gas_station(52, 42)

    _car(Vector3(-20, 0, -2.6), 5.0, Color(0.5, 0.15, 0.12))
    _car(Vector3(14, 0, 2.6), 175.0, Color(0.15, 0.25, 0.4))
    _car(Vector3(-45, 0, 2.5), 0.0, Color(0.6, 0.6, 0.55))
    _car(Vector3(2.6, 0, -26), 92.0, Color(0.2, 0.3, 0.2))
    _car(Vector3(-2.6, 0, 30), 80.0, Color(0.55, 0.5, 0.2))
    _car(Vector3(60, 0, -2.5), 10.0, Color(0.3, 0.3, 0.32))

    _boundary()
    _trees(60)


# ---------------------------------------------------------------- helpers
func _mat(c: Color, rough := 0.9) -> StandardMaterial3D:
    var key := str(c) + str(rough)
    if _mats.has(key):
        return _mats[key]
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = rough
    _mats[key] = m
    return m


func _part(body: StaticBody3D, lp: Vector3, size: Vector3, color: Color) -> void:
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    mi.mesh = bm
    mi.material_override = _mat(color)
    mi.position = lp
    body.add_child(mi)
    var cs := CollisionShape3D.new()
    var sh := BoxShape3D.new()
    sh.size = size
    cs.shape = sh
    cs.position = lp
    body.add_child(cs)


func _box(pos: Vector3, size: Vector3, color: Color) -> void:
    var body := StaticBody3D.new()
    body.position = pos
    _part(body, Vector3.ZERO, size, color)
    add_child(body)


func _plane(pos: Vector3, size: Vector2, color: Color) -> void:
    var mi := MeshInstance3D.new()
    var pm := PlaneMesh.new()
    pm.size = size
    mi.mesh = pm
    mi.position = pos
    mi.material_override = _mat(color, 0.95)
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(mi)


# ---------------------------------------------------------------- terrain
func _ground() -> void:
    var body := StaticBody3D.new()
    var mi := MeshInstance3D.new()
    var pm := PlaneMesh.new()
    pm.size = Vector2(600, 600)
    mi.mesh = pm
    mi.material_override = _mat(Color(0.2, 0.27, 0.16), 1.0)
    body.add_child(mi)
    var cs := CollisionShape3D.new()
    var sh := BoxShape3D.new()
    sh.size = Vector3(600, 2, 600)
    cs.shape = sh
    cs.position.y = -1.0
    body.add_child(cs)
    add_child(body)


func _roads() -> void:
    var asphalt := Color(0.13, 0.13, 0.14)
    _plane(Vector3(0, 0.05, 0), Vector2(HALF * 2.0 + 20.0, 10), asphalt)
    _plane(Vector3(0, 0.05, 0), Vector2(10, HALF * 2.0 + 20.0), asphalt)
    var x := -HALF
    while x < HALF:
        if absf(x) > 7.0:
            _plane(Vector3(x, 0.07, 0), Vector2(3, 0.25), Color(0.7, 0.65, 0.3))
            _plane(Vector3(0, 0.07, x), Vector2(0.25, 3), Color(0.7, 0.65, 0.3))
        x += 8.0


func _boundary() -> void:
    var t := 1.0
    var span := HALF * 2.0 + 2.0
    for spec in [
        [Vector3(HALF, 5, 0), Vector3(t, 10, span)],
        [Vector3(-HALF, 5, 0), Vector3(t, 10, span)],
        [Vector3(0, 5, HALF), Vector3(span, 10, t)],
        [Vector3(0, 5, -HALF), Vector3(span, 10, t)],
    ]:
        var body := StaticBody3D.new()
        body.position = spec[0]
        var cs := CollisionShape3D.new()
        var sh := BoxShape3D.new()
        sh.size = spec[1]
        cs.shape = sh
        body.add_child(cs)
        add_child(body)


# ---------------------------------------------------------------- structures
func _building(cx: float, cz: float, w: float, d: float, h: float, wall: Color, door_south: bool) -> void:
    var t := 0.25
    var g := 1.8
    building_rects.append(Rect2(cx - w / 2.0 - 1.5, cz - d / 2.0 - 1.5, w + 3.0, d + 3.0))
    var fz := cz + d / 2.0 if door_south else cz - d / 2.0
    var bz := cz - d / 2.0 if door_south else cz + d / 2.0
    _box(Vector3(cx, h / 2.0, bz), Vector3(w, h, t), wall)
    _box(Vector3(cx - w / 2.0, h / 2.0, cz), Vector3(t, h, d), wall)
    _box(Vector3(cx + w / 2.0, h / 2.0, cz), Vector3(t, h, d), wall)
    var seg := (w - g) / 2.0
    _box(Vector3(cx - g / 2.0 - seg / 2.0, h / 2.0, fz), Vector3(seg, h, t), wall)
    _box(Vector3(cx + g / 2.0 + seg / 2.0, h / 2.0, fz), Vector3(seg, h, t), wall)
    _box(Vector3(cx, (2.3 + h) / 2.0, fz), Vector3(g, h - 2.3, t), wall)  # lintel over doorway
    _box(Vector3(cx, h + 0.15, cz), Vector3(w + 0.6, 0.3, d + 0.6), Color(0.2, 0.18, 0.17))
    _plane(Vector3(cx, 0.06, cz), Vector2(w - t, d - t), Color(0.32, 0.25, 0.2))
    var light := OmniLight3D.new()
    light.position = Vector3(cx, h - 0.6, cz)
    light.omni_range = maxf(w, d) * 0.9
    light.light_energy = 1.2
    light.light_color = Color(1.0, 0.85, 0.6)
    add_child(light)
    for i in 2:
        var fx := cx + _rng.randf_range(-w * 0.3, w * 0.3)
        var fzz := cz + _rng.randf_range(-d * 0.3, d * 0.3)
        _box(Vector3(fx, 0.4, fzz), Vector3(_rng.randf_range(0.8, 1.6), 0.8, _rng.randf_range(0.6, 1.0)), Color(0.38, 0.27, 0.18))


func _gas_station(cx: float, cz: float) -> void:
    building_rects.append(Rect2(cx - 8.0, cz - 6.0, 16.0, 12.0))
    _box(Vector3(cx, 4.5, cz), Vector3(12, 0.4, 8), Color(0.6, 0.15, 0.12))
    for sx in [-5.0, 5.0]:
        for sz in [-3.0, 3.0]:
            _box(Vector3(cx + sx, 2.25, cz + sz), Vector3(0.5, 4.5, 0.5), Color(0.7, 0.7, 0.7))
    _box(Vector3(cx - 2.0, 0.75, cz), Vector3(0.8, 1.5, 0.6), Color(0.7, 0.2, 0.15))
    _box(Vector3(cx + 2.0, 0.75, cz), Vector3(0.8, 1.5, 0.6), Color(0.7, 0.2, 0.15))


func _car(pos: Vector3, rot_deg: float, color: Color) -> void:
    var body := StaticBody3D.new()
    body.position = pos
    body.rotation_degrees.y = rot_deg
    _part(body, Vector3(0, 0.6, 0), Vector3(1.9, 0.7, 4.3), color)
    _part(body, Vector3(0, 1.2, 0.2), Vector3(1.7, 0.6, 2.2), color.darkened(0.3))
    add_child(body)


func _trees(count: int) -> void:
    var placed := 0
    var attempts := 0
    while placed < count and attempts < count * 20:
        attempts += 1
        var x := _rng.randf_range(-HALF + 4.0, HALF - 4.0)
        var z := _rng.randf_range(-HALF + 4.0, HALF - 4.0)
        if absf(x) < 9.0 or absf(z) < 9.0:
            continue
        var blocked := false
        for r in building_rects:
            if r.grow(3.0).has_point(Vector2(x, z)):
                blocked = true
                break
        if blocked:
            continue
        _tree(x, z)
        placed += 1


func _tree(x: float, z: float) -> void:
    var body := StaticBody3D.new()
    body.position = Vector3(x, 0, z)
    var trunk := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = 0.18
    cm.bottom_radius = 0.25
    cm.height = 3.0
    cm.radial_segments = 8
    trunk.mesh = cm
    trunk.position.y = 1.5
    trunk.material_override = _mat(Color(0.28, 0.2, 0.13))
    body.add_child(trunk)
    var crown := MeshInstance3D.new()
    var sm := SphereMesh.new()
    sm.radius = _rng.randf_range(1.4, 2.0)
    sm.height = sm.radius * 2.0
    sm.radial_segments = 8
    sm.rings = 4
    crown.mesh = sm
    crown.position.y = 3.8
    crown.material_override = _mat(Color(0.14, 0.24, 0.12))
    body.add_child(crown)
    var cs := CollisionShape3D.new()
    var cyl := CylinderShape3D.new()
    cyl.radius = 0.3
    cyl.height = 3.0
    cs.shape = cyl
    cs.position.y = 1.5
    body.add_child(cs)
    add_child(body)
