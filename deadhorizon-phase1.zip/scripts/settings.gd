extends Node
## Autoload "Settings": graphics presets + persistence (ConfigFile).
## Phase 1 options all map to real rendering state. SSAO/reflections/shader quality
## tiers arrive with the Survival Realism Shader System (Phase 7).

signal changed

const PATH := "user://settings.cfg"
const PRESET_NAMES := ["Very Low", "Low", "Medium", "High", "Ultra", "Custom"]
const PRESETS := [
    {"res_scale": 0.5, "shadow_q": 0, "shadow_dist": 20.0, "msaa": 0, "bloom": false, "fog": true, "view_dist": 60.0, "fps": 30, "vsync": true},
    {"res_scale": 0.65, "shadow_q": 1, "shadow_dist": 35.0, "msaa": 0, "bloom": false, "fog": true, "view_dist": 90.0, "fps": 30, "vsync": true},
    {"res_scale": 0.8, "shadow_q": 2, "shadow_dist": 55.0, "msaa": 0, "bloom": true, "fog": true, "view_dist": 130.0, "fps": 60, "vsync": true},
    {"res_scale": 1.0, "shadow_q": 3, "shadow_dist": 80.0, "msaa": 1, "bloom": true, "fog": true, "view_dist": 180.0, "fps": 60, "vsync": true},
    {"res_scale": 1.0, "shadow_q": 3, "shadow_dist": 120.0, "msaa": 2, "bloom": true, "fog": true, "view_dist": 250.0, "fps": 60, "vsync": true},
]

var values := {}


func _ready() -> void:
    values = PRESETS[2].duplicate()
    values["preset"] = 2
    values["touch_scale"] = 1.0
    load_settings()
    apply_global()


func set_preset(i: int) -> void:
    if i < 0 or i >= PRESETS.size():
        return
    for k in PRESETS[i]:
        values[k] = PRESETS[i][k]
    values["preset"] = i
    _commit()


func set_value(key: String, v, marks_custom := true) -> void:
    values[key] = v
    if marks_custom:
        values["preset"] = 5
    _commit()


func _commit() -> void:
    apply_global()
    save_settings()
    changed.emit()


func save_settings() -> void:
    var cfg := ConfigFile.new()
    for k in values:
        cfg.set_value("graphics", k, values[k])
    cfg.save(PATH)


func load_settings() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(PATH) != OK:
        return
    for k in values.keys():
        values[k] = cfg.get_value("graphics", k, values[k])


## Settings that live on the root viewport / engine (not on a specific scene).
func apply_global() -> void:
    Engine.max_fps = int(values["fps"])
    if values["vsync"]:
        DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_ENABLED)
    else:
        DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
    var vp := get_viewport()
    vp.scaling_3d_scale = float(values["res_scale"])
    match int(values["msaa"]):
        0:
            vp.msaa_3d = Viewport.MSAA_DISABLED
        1:
            vp.msaa_3d = Viewport.MSAA_2X
        _:
            vp.msaa_3d = Viewport.MSAA_4X
    var q := int(values["shadow_q"])
    var sizes: Array[int] = [1024, 1024, 2048, 4096]
    RenderingServer.directional_shadow_atlas_set_size(sizes[q], true)
    match q:
        0, 1:
            RenderingServer.directional_soft_shadow_filter_set_quality(RenderingServer.SHADOW_QUALITY_HARD)
        2:
            RenderingServer.directional_soft_shadow_filter_set_quality(RenderingServer.SHADOW_QUALITY_SOFT_LOW)
        _:
            RenderingServer.directional_soft_shadow_filter_set_quality(RenderingServer.SHADOW_QUALITY_SOFT_MEDIUM)


## Settings that live on the current scene's environment / sun / camera.
func apply_world(env: Environment, sun: DirectionalLight3D, cam: Camera3D) -> void:
    sun.shadow_enabled = int(values["shadow_q"]) > 0
    sun.directional_shadow_max_distance = float(values["shadow_dist"])
    var vd := float(values["view_dist"])
    cam.far = vd
    env.glow_enabled = bool(values["bloom"])
    env.fog_enabled = bool(values["fog"])
    env.fog_density = 2.8 / vd
