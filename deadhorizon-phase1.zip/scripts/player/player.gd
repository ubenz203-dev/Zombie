extends CharacterBody3D
## First-person player: movement, look, visible arms, basic melee.
## Input comes from touch_controls.gd (touch) with keyboard fallback for desktop testing:
## WASD move, Shift sprint, Space jump, F attack, right-mouse-drag look.

signal hurt
signal died

const Stats = preload("res://scripts/player/survival_stats.gd")

const WALK_SPEED := 3.5
const SPRINT_SPEED := 6.0
const JUMP_VELOCITY := 4.3
const LOOK_SENS := 0.005
const EYE_HEIGHT := 1.65
const ATTACK_RANGE := 1.9
const ATTACK_DAMAGE := 20.0
const ARM_Z := -0.25

var stats
var touch = null
var head: Node3D
var camera: Camera3D
var noise := 0.0  # radius (m) at which zombies can hear the player

var _arm_l: Node3D
var _arm_r: Node3D
var _gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")
var _bob := 0.0
var _bob_amp := 0.0
var _jump_queued := false
var _attack_cd := 0.0
var _swing_t := 1.0
var _noise_boost := 0.0


func _ready() -> void:
    collision_layer = 2
    collision_mask = 1 | 4
    add_to_group("player")
    var cs := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.35
    cap.height = 1.8
    cs.shape = cap
    cs.position.y = 0.9
    add_child(cs)

    head = Node3D.new()
    head.position.y = EYE_HEIGHT
    add_child(head)
    camera = Camera3D.new()
    camera.near = 0.04
    camera.fov = 75.0
    head.add_child(camera)
    camera.current = true
    _arm_l = _make_arm(-1.0)
    _arm_r = _make_arm(1.0)

    stats = Stats.new()
    add_child(stats)
    stats.died.connect(_on_died)


func _make_arm(side: float) -> Node3D:
    var pivot := Node3D.new()
    pivot.position = Vector3(0.24 * side, -0.30, ARM_Z)
    pivot.rotation_degrees = Vector3(-10.0, -8.0 * side, 0.0)
    var sleeve := _arm_part(Vector3(0.1, 0.1, 0.42), Color(0.15, 0.2, 0.28), Vector3(0, 0, -0.1))
    var hand := _arm_part(Vector3(0.085, 0.07, 0.12), Color(0.85, 0.68, 0.55), Vector3(0, 0, -0.36))
    pivot.add_child(sleeve)
    pivot.add_child(hand)
    camera.add_child(pivot)
    return pivot


func _arm_part(size: Vector3, color: Color, pos: Vector3) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    mi.mesh = bm
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = 0.9
    mi.material_override = m
    mi.position = pos
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    return mi


func queue_jump() -> void:
    _jump_queued = true


func take_damage(amount: float) -> void:
    if stats.dead:
        return
    stats.take_damage(amount)
    hurt.emit()


func attack() -> void:
    if stats.dead or _attack_cd > 0.0:
        return
    _attack_cd = 0.6
    _swing_t = 0.0
    _noise_boost = 0.6
    var fwd: Vector3 = -global_transform.basis.z
    var best = null
    var best_d := INF
    for z in get_tree().get_nodes_in_group("zombies"):
        if not z.active or not z.is_alive():
            continue
        var to: Vector3 = z.global_position - global_position
        to.y = 0.0
        var d := to.length()
        if d > 0.001 and d < ATTACK_RANGE and fwd.dot(to / d) > 0.5 and d < best_d:
            best = z
            best_d = d
    if best != null:
        best.take_damage(ATTACK_DAMAGE, global_position)


func _process(delta: float) -> void:
    _attack_cd = maxf(0.0, _attack_cd - delta)
    _noise_boost = maxf(0.0, _noise_boost - delta)
    if stats.dead:
        return
    var look := Vector2.ZERO
    if touch != null:
        look = touch.look_delta
        touch.look_delta = Vector2.ZERO
    rotation.y -= look.x * LOOK_SENS
    head.rotation.x = clampf(head.rotation.x - look.y * LOOK_SENS, deg_to_rad(-80.0), deg_to_rad(80.0))


func _physics_process(delta: float) -> void:
    if stats.dead:
        velocity.x = 0.0
        velocity.z = 0.0
        return
    var input := Vector2.ZERO
    if touch != null:
        input = touch.move_vec
    var kx := int(Input.is_physical_key_pressed(KEY_D)) - int(Input.is_physical_key_pressed(KEY_A))
    var ky := int(Input.is_physical_key_pressed(KEY_S)) - int(Input.is_physical_key_pressed(KEY_W))
    if kx != 0 or ky != 0:
        input = Vector2(kx, ky).normalized()
    if Input.is_physical_key_pressed(KEY_F):
        attack()

    var want_sprint: bool = Input.is_physical_key_pressed(KEY_SHIFT) or (touch != null and touch.sprint_on)
    var has_input := input.length() > 0.1
    var sprinting := want_sprint and has_input and stats.stamina > 5.0
    var speed := SPRINT_SPEED if sprinting else WALK_SPEED
    var dir: Vector3 = transform.basis * Vector3(input.x, 0.0, input.y)
    velocity.x = move_toward(velocity.x, dir.x * speed, 40.0 * delta)
    velocity.z = move_toward(velocity.z, dir.z * speed, 40.0 * delta)

    if is_on_floor():
        if _jump_queued or Input.is_physical_key_pressed(KEY_SPACE):
            velocity.y = JUMP_VELOCITY
    else:
        velocity.y -= _gravity * delta
    _jump_queued = false
    move_and_slide()

    var base_noise := 0.0
    if has_input:
        base_noise = 14.0 if sprinting else 6.0
    noise = maxf(base_noise, 12.0 if _noise_boost > 0.0 else 0.0)
    stats.tick(delta, sprinting, has_input)
    _animate_hands(delta, has_input and is_on_floor(), sprinting)


func _animate_hands(delta: float, moving: bool, sprinting: bool) -> void:
    if moving:
        _bob += delta * (11.0 if sprinting else 7.5)
    var target_amp := 0.0
    if moving:
        target_amp = 0.035 if sprinting else 0.022
    _bob_amp = lerpf(_bob_amp, target_amp, minf(1.0, delta * 8.0))
    head.position.y = EYE_HEIGHT + sin(_bob * 2.0) * _bob_amp
    var sway := sin(_bob) * _bob_amp * 2.0
    var lift := cos(_bob * 2.0) * _bob_amp * 0.6
    var p := 0.0
    if _swing_t < 1.0:
        _swing_t = minf(1.0, _swing_t + delta / 0.3)
        p = sin(_swing_t * PI)
    _arm_l.position = Vector3(-0.24 + sway * 0.5, -0.30 + lift, ARM_Z)
    _arm_r.position = Vector3(0.24 - sway * 0.5, -0.30 + lift, ARM_Z - p * 0.28)
    _arm_r.rotation_degrees.x = -10.0 + p * 25.0


func _on_died() -> void:
    died.emit()
    var tw := create_tween()
    tw.tween_property(head, "position:y", 0.35, 0.6)
    tw.parallel().tween_property(head, "rotation:z", deg_to_rad(70.0), 0.6)
