extends Node
## Survival stats component (0-100, 100 = best). Phase 1: health, hunger, thirst, stamina, fatigue.

signal died

var health := 100.0
var hunger := 100.0
var thirst := 100.0
var stamina := 100.0
var fatigue := 100.0
var dead := false


func tick(delta: float, sprinting: bool, moving: bool) -> void:
    if dead:
        return
    hunger = maxf(0.0, hunger - delta * 0.08)
    thirst = maxf(0.0, thirst - delta * 0.12)
    fatigue = maxf(0.0, fatigue - delta * 0.03)
    if sprinting:
        stamina = maxf(0.0, stamina - delta * 18.0)
    else:
        stamina = minf(100.0, stamina + delta * (12.0 if moving else 22.0))
    if hunger <= 0.0 or thirst <= 0.0:
        take_damage(delta)
    elif health < 100.0 and hunger > 50.0 and thirst > 50.0:
        health = minf(100.0, health + delta * 0.2)


func take_damage(amount: float) -> void:
    if dead:
        return
    health = maxf(0.0, health - amount)
    if health <= 0.0:
        dead = true
        died.emit()
