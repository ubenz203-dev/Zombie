extends RefCounted
## Shared dark survival theme. Large fonts/buttons for small touch screens.

static var _theme: Theme


static func get_theme() -> Theme:
    if _theme != null:
        return _theme
    var t := Theme.new()
    t.default_font_size = 24
    t.set_stylebox("normal", "Button", _box(Color(0.12, 0.12, 0.13, 0.95), Color(0.4, 0.1, 0.1), 2))
    t.set_stylebox("hover", "Button", _box(Color(0.18, 0.14, 0.14, 0.95), Color(0.65, 0.15, 0.15), 2))
    t.set_stylebox("pressed", "Button", _box(Color(0.35, 0.08, 0.08, 0.95), Color(0.8, 0.2, 0.2), 2))
    t.set_stylebox("panel", "PanelContainer", _box(Color(0.07, 0.07, 0.08, 0.96), Color(0.35, 0.08, 0.08), 2))
    t.set_color("font_color", "Label", Color(0.9, 0.88, 0.82))
    t.set_color("font_color", "Button", Color(0.92, 0.9, 0.85))
    t.set_color("font_hover_color", "Button", Color(1, 1, 1))
    _theme = t
    return t


static func _box(bg: Color, border: Color, bw: int) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = bg
    s.border_color = border
    s.set_border_width_all(bw)
    s.set_corner_radius_all(6)
    s.set_content_margin_all(14)
    return s
