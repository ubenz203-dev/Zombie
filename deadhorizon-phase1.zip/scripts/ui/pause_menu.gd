extends CanvasLayer
## Pause / death overlay. Runs while the tree is paused.

signal resume_pressed
signal restart_pressed
signal menu_pressed

const UITheme = preload("res://scripts/ui/ui_theme.gd")
const SettingsPanel = preload("res://scripts/ui/settings_panel.gd")

var _title: Label
var _resume_btn: Button
var _menu_box: Control
var _settings_box: Control


func _ready() -> void:
    layer = 20
    process_mode = Node.PROCESS_MODE_ALWAYS
    visible = false
    var root := Control.new()
    root.theme = UITheme.get_theme()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(root)
    var dim := ColorRect.new()
    dim.color = Color(0, 0, 0, 0.7)
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.add_child(dim)

    var center := CenterContainer.new()
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.add_child(center)
    _menu_box = center
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 14)
    box.custom_minimum_size = Vector2(380, 0)
    center.add_child(box)
    _title = Label.new()
    _title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _title.add_theme_font_size_override("font_size", 48)
    _title.add_theme_color_override("font_color", Color(0.75, 0.15, 0.15))
    box.add_child(_title)
    _resume_btn = _button(box, "Resume", func(): resume_pressed.emit())
    _button(box, "Settings", _show_settings)
    _button(box, "Restart", func(): restart_pressed.emit())
    _button(box, "Main Menu", func(): menu_pressed.emit())

    _settings_box = CenterContainer.new()
    _settings_box.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _settings_box.visible = false
    var panel := SettingsPanel.new()
    panel.closed.connect(_show_menu)
    _settings_box.add_child(panel)
    root.add_child(_settings_box)


func _button(parent: Control, text: String, cb: Callable) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = Vector2(0, 68)
    b.pressed.connect(cb)
    parent.add_child(b)
    return b


func open(title: String, can_resume: bool) -> void:
    _title.text = title
    _resume_btn.visible = can_resume
    _show_menu()
    visible = true


func close() -> void:
    visible = false


func _show_settings() -> void:
    _menu_box.visible = false
    _settings_box.visible = true


func _show_menu() -> void:
    _settings_box.visible = false
    _menu_box.visible = true
