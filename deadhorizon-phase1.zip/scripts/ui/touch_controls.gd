extends Control
## Custom multi-touch controls: floating joystick (left), look drag (right),
## action buttons (HIT / JUMP / RUN toggle / pause). Handles raw ScreenTouch/ScreenDrag
## so several fingers work at once. Positions scale with screen size and Settings.touch_scale.

signal attack_pressed
signal jump_pressed
signal pause_pressed

var move_vec := Vector2.ZERO
var look_delta := Vector2.ZERO
var sprint_on := false

var _vp := Vector2(1280, 720)
var _buttons := {}
var _joy_r := 100.0
var _joy_home := Vector2.ZERO
var _move_touch := -1
var _move_origin := Vector2.ZERO
var _move_knob := Vector2.ZERO
var _look_touch := -1
var _btn_touches := {}  # touch index -> button id


func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    get_viewport().size_changed.connect(_layout)
    Settings.changed.connect(_layout)
    _layout()


func reset() -> void:
    move_vec = Vector2.ZERO
    look_delta = Vector2.ZERO
    _move_touch = -1
    _look_touch = -1
    _btn_touches.clear()
    queue_redraw()


func _layout() -> void:
    _vp = get_viewport_rect().size
    var sf: float = float(Settings.values["touch_scale"])
    var u := minf(_vp.x, _vp.y)
    var r := u * 0.09 * sf
    var pad := u * 0.04
    var ra := r * 1.45
    _joy_r = u * 0.16 * sf
    _joy_home = Vector2(pad + _joy_r + u * 0.04, _vp.y - pad - _joy_r - u * 0.04)
    var ac := Vector2(_vp.x - pad - ra, _vp.y - pad - ra)
    _buttons = {
        "attack": {"center": ac, "radius": ra, "label": "HIT"},
        "jump": {"center": Vector2(ac.x, ac.y - ra - pad - r), "radius": r, "label": "JUMP"},
        "sprint": {"center": Vector2(ac.x - ra - pad - r, ac.y + ra * 0.2), "radius": r, "label": "RUN"},
        "pause": {"center": Vector2(_vp.x - pad - r * 0.7, pad + r * 0.7), "radius": r * 0.7, "label": "II"},
    }
    queue_redraw()


func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            _on_press(event.index, event.position)
        else:
            _on_release(event.index)
    elif event is InputEventScreenDrag:
        _on_drag(event.index, event.position, event.relative)
    elif event is InputEventMouseMotion and not OS.has_feature("mobile"):
        if event.button_mask & MOUSE_BUTTON_MASK_RIGHT:
            look_delta += event.relative


func _on_press(idx: int, pos: Vector2) -> void:
    for id in _buttons:
        var b: Dictionary = _buttons[id]
        if pos.distance_to(b["center"]) <= float(b["radius"]) * 1.15:
            _btn_touches[idx] = id
            match id:
                "attack":
                    attack_pressed.emit()
                "jump":
                    jump_pressed.emit()
                "sprint":
                    sprint_on = not sprint_on
                "pause":
                    pause_pressed.emit()
            queue_redraw()
            return
    if pos.x < _vp.x * 0.45:
        if _move_touch == -1:
            _move_touch = idx
            _move_origin = pos
            _move_knob = pos
    elif _look_touch == -1:
        _look_touch = idx
    queue_redraw()


func _on_drag(idx: int, pos: Vector2, rel: Vector2) -> void:
    if idx == _move_touch:
        var d := pos - _move_origin
        _move_knob = _move_origin + d.limit_length(_joy_r)
        var v := (d / _joy_r).limit_length(1.0)
        move_vec = Vector2.ZERO if v.length() < 0.12 else v
        queue_redraw()
    elif idx == _look_touch:
        look_delta += rel


func _on_release(idx: int) -> void:
    if idx == _move_touch:
        _move_touch = -1
        move_vec = Vector2.ZERO
    elif idx == _look_touch:
        _look_touch = -1
    _btn_touches.erase(idx)
    queue_redraw()


func _draw() -> void:
    var font := ThemeDB.fallback_font
    if _move_touch != -1:
        draw_circle(_move_origin, _joy_r, Color(1, 1, 1, 0.10))
        draw_arc(_move_origin, _joy_r, 0.0, TAU, 48, Color(1, 1, 1, 0.35), 3.0, true)
        draw_circle(_move_knob, _joy_r * 0.4, Color(1, 1, 1, 0.35))
    else:
        draw_arc(_joy_home, _joy_r, 0.0, TAU, 48, Color(1, 1, 1, 0.15), 3.0, true)
    for id in _buttons:
        var b: Dictionary = _buttons[id]
        var c: Vector2 = b["center"]
        var rad: float = b["radius"]
        var pressed: bool = _btn_touches.values().has(id) or (id == "sprint" and sprint_on)
        var fill := Color(0.8, 0.2, 0.2, 0.35) if pressed else Color(1, 1, 1, 0.10)
        draw_circle(c, rad, fill)
        draw_arc(c, rad, 0.0, TAU, 40, Color(1, 1, 1, 0.4), 3.0, true)
        var fs := int(rad * 0.45)
        draw_string(font, Vector2(c.x - rad, c.y + fs * 0.35), String(b["label"]), HORIZONTAL_ALIGNMENT_CENTER, rad * 2.0, fs, Color(1, 1, 1, 0.85))
