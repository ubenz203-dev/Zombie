extends PanelContainer
## Graphics settings UI. Every control writes through the Settings autoload.

signal closed

const UITheme = preload("res://scripts/ui/ui_theme.gd")
const FPS_OPTIONS := [30, 60, 90, 0]

var _opts := {}     # key -> {"node": OptionButton, "vals": Array}
var _sliders := {}  # key -> {"node": HSlider, "label": Label, "fmt": String}
var _checks := {}   # key -> CheckBox


func _ready() -> void:
    theme = UITheme.get_theme()
    custom_minimum_size = Vector2(640, 0)
    var root := VBoxContainer.new()
    root.add_theme_constant_override("separation", 10)
    add_child(root)
    var title := Label.new()
    title.text = "GRAPHICS SETTINGS"
    root.add_child(title)
    var scroll := ScrollContainer.new()
    scroll.custom_minimum_size = Vector2(0, 340)
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    root.add_child(scroll)
    var list := VBoxContainer.new()
    list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    list.add_theme_constant_override("separation", 8)
    scroll.add_child(list)

    _add_option(list, "Preset", "preset", Settings.PRESET_NAMES, [])
    _add_slider(list, "Resolution scale", "res_scale", 0.4, 1.0, 0.05, "%.2f")
    _add_option(list, "Shadow quality", "shadow_q", ["Off", "Low", "Medium", "High"], [])
    _add_slider(list, "Shadow distance", "shadow_dist", 10.0, 120.0, 5.0, "%d m")
    _add_option(list, "Anti-aliasing", "msaa", ["Off", "MSAA 2x", "MSAA 4x"], [])
    _add_check(list, "Bloom", "bloom")
    _add_check(list, "Fog", "fog")
    _add_slider(list, "View distance", "view_dist", 40.0, 250.0, 10.0, "%d m")
    _add_option(list, "FPS limit", "fps", ["30", "60", "90", "Unlimited"], FPS_OPTIONS)
    _add_check(list, "VSync", "vsync")
    _add_slider(list, "Touch button size", "touch_scale", 0.7, 1.4, 0.05, "%.2f")

    var close := Button.new()
    close.text = "Back"
    close.custom_minimum_size = Vector2(0, 64)
    close.pressed.connect(func(): closed.emit())
    root.add_child(close)
    Settings.changed.connect(refresh)
    refresh()


func _row(parent: Control, text: String, ctrl: Control) -> void:
    var h := HBoxContainer.new()
    var l := Label.new()
    l.text = text
    l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    h.add_child(l)
    h.add_child(ctrl)
    parent.add_child(h)


func _add_option(parent: Control, text: String, key: String, labels: Array, vals: Array) -> void:
    var ob := OptionButton.new()
    ob.custom_minimum_size = Vector2(240, 52)
    for l in labels:
        ob.add_item(str(l))
    ob.item_selected.connect(func(i: int): _on_option(key, i, vals))
    _opts[key] = {"node": ob, "vals": vals}
    _row(parent, text, ob)


func _add_slider(parent: Control, text: String, key: String, lo: float, hi: float, step: float, fmt: String) -> void:
    var box := HBoxContainer.new()
    var s := HSlider.new()
    s.min_value = lo
    s.max_value = hi
    s.step = step
    s.custom_minimum_size = Vector2(190, 52)
    s.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    var val := Label.new()
    val.custom_minimum_size = Vector2(80, 0)
    val.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    s.value_changed.connect(func(v: float): Settings.set_value(key, v, key != "touch_scale"))
    box.add_child(s)
    box.add_child(val)
    _sliders[key] = {"node": s, "label": val, "fmt": fmt}
    _row(parent, text, box)


func _add_check(parent: Control, text: String, key: String) -> void:
    var cb := CheckBox.new()
    cb.custom_minimum_size = Vector2(240, 52)
    cb.toggled.connect(func(on: bool): Settings.set_value(key, on))
    _checks[key] = cb
    _row(parent, text, cb)


func _on_option(key: String, i: int, vals: Array) -> void:
    if key == "preset":
        Settings.set_preset(i)
    else:
        var v = vals[i] if vals.size() > 0 else i
        Settings.set_value(key, v)


func refresh() -> void:
    for key in _opts:
        var ob: OptionButton = _opts[key]["node"]
        var vals: Array = _opts[key]["vals"]
        var cur = Settings.values[key]
        ob.select(vals.find(cur) if vals.size() > 0 else int(cur))
    for key in _sliders:
        var s: HSlider = _sliders[key]["node"]
        var l: Label = _sliders[key]["label"]
        var cur: float = float(Settings.values[key])
        s.set_value_no_signal(cur)
        l.text = String(_sliders[key]["fmt"]) % cur
    for key in _checks:
        var cb: CheckBox = _checks[key]
        cb.set_pressed_no_signal(bool(Settings.values[key]))
