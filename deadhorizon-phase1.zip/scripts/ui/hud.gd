extends CanvasLayer
## Survival HUD: status bars, clock + compass, FPS/zombie debug info, quick slots, hurt flash.

const UITheme = preload("res://scripts/ui/ui_theme.gd")

var kills := 0

var _stats = null
var _player = null
var _bars := {}
var _clock_label: Label
var _info_label: Label
var _flash: ColorRect
var _minutes := 8.0 * 60.0
var _info_t := 0.0


func _ready() -> void:
    layer = 1
    var root := Control.new()
    root.theme = UITheme.get_theme()
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(root)

    var box := VBoxContainer.new()
    box.position = Vector2(20, 14)
    box.add_theme_constant_override("separation", 4)
    root.add_child(box)
    _add_bar(box, "health", "HEALTH", Color(0.75, 0.15, 0.15))
    _add_bar(box, "hunger", "HUNGER", Color(0.85, 0.55, 0.15))
    _add_bar(box, "thirst", "THIRST", Color(0.2, 0.5, 0.85))
    _add_bar(box, "stamina", "STAMINA", Color(0.3, 0.7, 0.3))
    _add_bar(box, "fatigue", "REST", Color(0.55, 0.4, 0.75))

    _clock_label = Label.new()
    _clock_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _clock_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _clock_label.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    _clock_label.offset_top = 10
    _clock_label.add_theme_font_size_override("font_size", 20)
    root.add_child(_clock_label)

    _info_label = Label.new()
    _info_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    _info_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _info_label.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    _info_label.offset_top = 14
    _info_label.offset_right = -140
    _info_label.add_theme_font_size_override("font_size", 16)
    root.add_child(_info_label)

    var dot := ColorRect.new()
    dot.color = Color(1, 1, 1, 0.7)
    dot.mouse_filter = Control.MOUSE_FILTER_IGNORE
    dot.custom_minimum_size = Vector2(5, 5)
    dot.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
    root.add_child(dot)

    # Quick slots + weapon status (placeholders until the Phase 4 inventory).
    var slots := HBoxContainer.new()
    slots.add_theme_constant_override("separation", 8)
    slots.mouse_filter = Control.MOUSE_FILTER_IGNORE
    slots.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
    slots.offset_top = -86
    slots.offset_bottom = -20
    slots.grow_horizontal = Control.GROW_DIRECTION_BOTH
    for i in 4:
        var p := PanelContainer.new()
        p.custom_minimum_size = Vector2(56, 56)
        p.mouse_filter = Control.MOUSE_FILTER_IGNORE
        var n := Label.new()
        n.text = str(i + 1)
        n.add_theme_font_size_override("font_size", 14)
        p.add_child(n)
        slots.add_child(p)
    var weapon := Label.new()
    weapon.text = "Fists"
    weapon.add_theme_font_size_override("font_size", 16)
    slots.add_child(weapon)
    root.add_child(slots)

    _flash = ColorRect.new()
    _flash.color = Color(0.8, 0.0, 0.0, 0.0)
    _flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _flash.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.add_child(_flash)


func _add_bar(parent: Control, key: String, text: String, color: Color) -> void:
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 8)
    var l := Label.new()
    l.text = text
    l.custom_minimum_size = Vector2(96, 0)
    l.add_theme_font_size_override("font_size", 18)
    row.add_child(l)
    var bar := ProgressBar.new()
    bar.custom_minimum_size = Vector2(190, 16)
    bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    bar.show_percentage = false
    bar.max_value = 100.0
    bar.value = 100.0
    var bg := StyleBoxFlat.new()
    bg.bg_color = Color(0, 0, 0, 0.55)
    var fg := StyleBoxFlat.new()
    fg.bg_color = color
    bar.add_theme_stylebox_override("background", bg)
    bar.add_theme_stylebox_override("fill", fg)
    row.add_child(bar)
    parent.add_child(row)
    _bars[key] = bar


func bind(player) -> void:
    _player = player
    _stats = player.stats
    player.hurt.connect(_flash_red)


func _flash_red() -> void:
    _flash.color.a = 0.35
    var tw := create_tween()
    tw.tween_property(_flash, "color:a", 0.0, 0.4)


func _process(delta: float) -> void:
    if _stats == null:
        return
    _minutes += delta  # 1 real second = 1 game minute (day/night arrives in Phase 6)
    _bars["health"].value = _stats.health
    _bars["hunger"].value = _stats.hunger
    _bars["thirst"].value = _stats.thirst
    _bars["stamina"].value = _stats.stamina
    _bars["fatigue"].value = _stats.fatigue

    var total := int(_minutes)
    var day := total / (24 * 60) + 1
    var hour := (total / 60) % 24
    var minute := total % 60
    var yaw: float = _player.rotation.y
    var heading := fposmod(-rad_to_deg(yaw), 360.0)
    var names := ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]
    var dir_name: String = names[int(roundf(heading / 45.0)) % 8]
    _clock_label.text = "Day %d  %02d:%02d\n%s  %d°" % [day, hour, minute, dir_name, int(heading)]

    _info_t -= delta
    if _info_t <= 0.0:
        _info_t = 0.5
        var active := 0
        for z in get_tree().get_nodes_in_group("zombies"):
            if z.active and z.is_alive():
                active += 1
        _info_label.text = "FPS %d   Zombies %d   Kills %d" % [Engine.get_frames_per_second(), active, kills]
