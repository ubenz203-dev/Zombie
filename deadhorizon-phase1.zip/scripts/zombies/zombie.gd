extends CharacterBody3D
## Pooled zombie: procedural low-poly model + state machine.
## States: IDLE, WANDER, CHASE, SEARCH, ATTACK, DEAD.
## Detection: sight (range + cone + line-of-sight ray, throttled) and hearing (player.noise).
## NOTE: no pathfinding yet - zombies steer straight at targets and slide along walls.

signal killed

enum State { IDLE, WANDER, CHASE, SEARCH, ATTACK, DEAD }

const SIGHT_RANGE := 24.0
const SIGHT_FOV_COS := 0.3
const MELEE_RANGE := 1.5
const ATTACK_DAMAGE := 12.0
const WINDUP := 0.55

var state: State = State.IDLE
var active := false
var hp := 60.0
var walk_speed := 1.0
var chase_speed := 2.2
var player = null  # player.gd instance (untyped on purpose)
var home := Vector3.ZERO

var _target_pos := Vector3.ZERO
var _last_known := Vector3.ZERO
var _timer := 0.0
var _sight_timer := 0.0
var _lost_time := 0.0
var _attack_t := 0.0
var _attack_cd := 0.0
var _can_see := false
var _anim := 0.0
var _side := 1.0
var _knock := Vector3.ZERO
var _gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")
var _tween: Tween

var _body: Node3D
var _leg_l: Node3D
var _leg_r: Node3D
var _arms: Array[Node3D] = []
var _skin: StandardMaterial3D
var _cloth: StandardMaterial3D


func _ready() -> void:
    add_to_group("zombies")
    var cs := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.35
    cap.height = 1.8
    cs.shape = cap
    cs.position.y = 0.9
    add_child(cs)
    _build_model()
    deactivate()


func is_alive() -> bool:
    return state != State.DEAD


# ---------------------------------------------------------------- pooling
func activate(pos: Vector3, target) -> void:
    if _tween != null:
        _tween.kill()
    player = target
    global_position = pos
    home = pos
    velocity = Vector3.ZERO
    _knock = Vector3.ZERO
    _body.rotation = Vector3.ZERO
    _attack_cd = 0.0
    _can_see = false
    _side = 1.0 if randf() < 0.5 else -1.0
    active = true
    visible = true
    collision_layer = 4
    collision_mask = 1 | 2
    process_mode = Node.PROCESS_MODE_INHERIT
    _roll_variant()
    _set_state(State.IDLE if randf() < 0.5 else State.WANDER)


func deactivate() -> void:
    active = false
    visible = false
    collision_layer = 0
    collision_mask = 0
    state = State.IDLE
    process_mode = Node.PROCESS_MODE_DISABLED


func _roll_variant() -> void:
    var r := randf()
    var s := randf_range(0.95, 1.08)
    if r < 0.6:      # shambler
        chase_speed = randf_range(1.8, 2.3)
        walk_speed = 0.8
        hp = 60.0
    elif r < 0.9:    # walker
        chase_speed = randf_range(2.6, 3.1)
        walk_speed = 1.1
        hp = 70.0
    else:            # runner
        chase_speed = randf_range(3.8, 4.4)
        walk_speed = 1.4
        hp = 40.0
        s *= 0.95
    _body.scale = Vector3.ONE * s
    _skin.albedo_color = Color.from_hsv(randf_range(0.22, 0.32), randf_range(0.2, 0.4), randf_range(0.4, 0.6))
    _cloth.albedo_color = Color.from_hsv(randf(), randf_range(0.0, 0.4), randf_range(0.15, 0.4))


# ---------------------------------------------------------------- model
func _new_mat(c: Color) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = 0.95
    return m


func _box_mesh(size: Vector3) -> BoxMesh:
    var bm := BoxMesh.new()
    bm.size = size
    return bm


func _mesh(parent: Node3D, mesh: Mesh, mat: Material, pos: Vector3) -> void:
    var mi := MeshInstance3D.new()
    mi.mesh = mesh
    mi.material_override = mat
    mi.position = pos
    parent.add_child(mi)


func _limb(pivot_pos: Vector3, size: Vector3, mesh_pos: Vector3, mat: Material) -> Node3D:
    var pivot := Node3D.new()
    pivot.position = pivot_pos
    _mesh(pivot, _box_mesh(size), mat, mesh_pos)
    _body.add_child(pivot)
    return pivot


func _build_model() -> void:
    _body = Node3D.new()
    add_child(_body)
    _skin = _new_mat(Color(0.5, 0.6, 0.45))
    _cloth = _new_mat(Color(0.3, 0.25, 0.22))
    var pants := _new_mat(Color(0.14, 0.16, 0.22))
    var eye := StandardMaterial3D.new()
    eye.albedo_color = Color(0.9, 0.1, 0.1)
    eye.emission_enabled = true
    eye.emission = Color(1.0, 0.1, 0.1)

    _mesh(_body, _box_mesh(Vector3(0.5, 0.65, 0.28)), _cloth, Vector3(0, 1.13, 0))
    var head := SphereMesh.new()
    head.radius = 0.16
    head.height = 0.32
    head.radial_segments = 8
    head.rings = 4
    _mesh(_body, head, _skin, Vector3(0, 1.7, 0))
    _mesh(_body, _box_mesh(Vector3(0.045, 0.03, 0.02)), eye, Vector3(-0.06, 1.72, -0.15))
    _mesh(_body, _box_mesh(Vector3(0.045, 0.03, 0.02)), eye, Vector3(0.06, 1.72, -0.15))
    _leg_l = _limb(Vector3(-0.13, 0.8, 0), Vector3(0.2, 0.8, 0.22), Vector3(0, -0.4, 0), pants)
    _leg_r = _limb(Vector3(0.13, 0.8, 0), Vector3(0.2, 0.8, 0.22), Vector3(0, -0.4, 0), pants)
    var arm_l := _limb(Vector3(-0.33, 1.42, 0), Vector3(0.13, 0.13, 0.65), Vector3(0, 0, -0.3), _skin)
    var arm_r := _limb(Vector3(0.33, 1.42, 0), Vector3(0.13, 0.13, 0.65), Vector3(0, 0, -0.3), _skin)
    _arms = [arm_l, arm_r]


# ---------------------------------------------------------------- AI
func _set_state(s: State) -> void:
    state = s
    match s:
        State.IDLE:
            _timer = randf_range(2.0, 5.0)
        State.WANDER:
            var a := randf() * TAU
            _target_pos = home + Vector3(cos(a), 0.0, sin(a)) * randf_range(3.0, 10.0)
            _timer = 8.0
        State.SEARCH:
            _timer = 4.0
        State.CHASE:
            _lost_time = 0.0
        State.ATTACK:
            _attack_t = 0.0


func _stop() -> void:
    velocity.x = 0.0
    velocity.z = 0.0


func _face(dir: Vector3, delta: float) -> void:
    if dir.length() < 0.01:
        return
    rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), minf(1.0, delta * 8.0))


## Returns true when the target has been reached.
func _move_to(target: Vector3, speed: float, delta: float) -> bool:
    var d := target - global_position
    d.y = 0.0
    var dist := d.length()
    if dist < 0.6:
        _stop()
        return true
    var dir := d / dist
    if is_on_wall():
        var n := get_wall_normal()
        var slid := dir.slide(n)
        if slid.length() < 0.2:
            slid = n.cross(Vector3.UP) * _side
        dir = slid.normalized()
    velocity.x = dir.x * speed
    velocity.z = dir.z * speed
    _face(dir, delta)
    return false


func _line_of_sight() -> bool:
    var space := get_world_3d().direct_space_state
    var from := global_position + Vector3(0, 1.6, 0)
    var pp: Vector3 = player.global_position
    var q := PhysicsRayQueryParameters3D.create(from, pp + Vector3(0, 1.4, 0), 1)
    return space.intersect_ray(q).is_empty()


func _perceive(delta: float, to_p: Vector3, dist: float) -> void:
    if player.stats.dead:
        if state == State.CHASE or state == State.ATTACK or state == State.SEARCH:
            _set_state(State.WANDER)
        _can_see = false
        return
    if state == State.CHASE and not _can_see:
        _lost_time += delta
        if _lost_time > 6.0:
            _set_state(State.SEARCH)
    _sight_timer -= delta
    if _sight_timer > 0.0:
        return
    _sight_timer = randf_range(0.2, 0.35)  # throttle: rays are staggered per zombie
    _can_see = false
    if dist < SIGHT_RANGE:
        var fwd: Vector3 = -global_transform.basis.z
        var in_cone := dist < 3.0 or fwd.dot(to_p / maxf(dist, 0.01)) > SIGHT_FOV_COS
        if in_cone:
            _can_see = _line_of_sight()
    var noise: float = player.noise
    var heard := dist < noise * (1.0 if _can_see else 0.6)
    if _can_see or heard:
        _last_known = player.global_position
        _lost_time = 0.0
        if state == State.IDLE or state == State.WANDER or state == State.SEARCH:
            _set_state(State.CHASE)


func take_damage(amount: float, from: Vector3) -> void:
    if state == State.DEAD:
        return
    hp -= amount
    var push := global_position - from
    push.y = 0.0
    _knock = push.normalized() * 4.0
    if hp <= 0.0:
        _die()
        return
    _last_known = from
    _lost_time = 0.0
    if state != State.CHASE:
        _set_state(State.CHASE)


func _die() -> void:
    state = State.DEAD
    collision_layer = 0
    collision_mask = 0
    killed.emit()
    _tween = create_tween()
    _tween.tween_property(_body, "rotation:x", PI / 2.0, 0.6).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
    _tween.tween_interval(5.0)
    _tween.tween_callback(deactivate)


func _physics_process(delta: float) -> void:
    if not active or player == null or state == State.DEAD:
        return
    _attack_cd = maxf(0.0, _attack_cd - delta)
    var to_p: Vector3 = player.global_position - global_position
    to_p.y = 0.0
    var dist := to_p.length()
    _perceive(delta, to_p, dist)
    if _can_see and state == State.CHASE:
        _last_known = player.global_position

    match state:
        State.IDLE:
            _stop()
            _timer -= delta
            if _timer <= 0.0:
                _set_state(State.WANDER)
        State.WANDER:
            _timer -= delta
            if _move_to(_target_pos, walk_speed, delta) or _timer <= 0.0:
                _set_state(State.IDLE)
        State.CHASE:
            if dist <= MELEE_RANGE and _attack_cd <= 0.0 and _can_see:
                _set_state(State.ATTACK)
            elif _move_to(_last_known, chase_speed, delta) and not _can_see:
                _set_state(State.SEARCH)
        State.SEARCH:
            _stop()
            rotation.y += delta * 1.2
            _timer -= delta
            if _timer <= 0.0:
                home = global_position
                _set_state(State.WANDER)
        State.ATTACK:
            _stop()
            _face(to_p.normalized(), delta)
            _attack_t += delta
            if dist > MELEE_RANGE + 1.2:
                _set_state(State.CHASE)
            elif _attack_t >= WINDUP:
                if dist <= MELEE_RANGE + 0.6:
                    player.take_damage(ATTACK_DAMAGE)
                _attack_cd = 1.3
                _set_state(State.CHASE)

    if is_on_floor():
        velocity.y = 0.0
    else:
        velocity.y -= _gravity * delta
    velocity.x += _knock.x
    velocity.z += _knock.z
    _knock = _knock.move_toward(Vector3.ZERO, 14.0 * delta)
    move_and_slide()
    _animate(delta)


func _animate(delta: float) -> void:
    var spd := Vector2(velocity.x, velocity.z).length()
    _anim += delta * (2.0 + spd * 2.2)
    var swing := sin(_anim) * clampf(spd * 0.5, 0.0, 0.7)
    _leg_l.rotation.x = swing
    _leg_r.rotation.x = -swing
    var target := -0.8
    if state == State.CHASE:
        target = 0.1
    elif state == State.ATTACK:
        target = 0.9 - clampf(_attack_t / WINDUP, 0.0, 1.0) * 1.5
    for a in _arms:
        a.rotation.x = lerpf(a.rotation.x, target, minf(1.0, delta * 10.0))
    _body.rotation.z = sin(_anim * 0.5) * 0.05
