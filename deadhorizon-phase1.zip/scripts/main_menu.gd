extends Control

const UITheme = preload("res://scripts/ui/ui_theme.gd")
const SettingsPanel = preload("res://scripts/ui/settings_panel.gd")

var _menu_box: Control
var _settings_box: Control


func _ready() -> void:
    theme = UITheme.get_theme()
    var bg := ColorRect.new()
    bg.color = Color(0.04, 0.04, 0.05)
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(bg)

    var center := CenterContainer.new()
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(center)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 14)
    box.custom_minimum_size = Vector2(420, 0)
    center.add_child(box)
    _menu_box = center

    var title := Label.new()
    title.text = "DEAD HORIZON"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 64)
    title.add_theme_color_override("font_color", Color(0.7, 0.12, 0.12))
    box.add_child(title)
    var sub := Label.new()
    sub.text = "Phase 1 prototype"
    sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    sub.add_theme_font_size_override("font_size", 20)
    box.add_child(sub)

    _button(box, "New Game", func(): get_tree().change_scene_to_file("res://scenes/game.tscn"))
    _button(box, "Settings", _show_settings)
    _button(box, "Quit", func(): get_tree().quit())

    _settings_box = CenterContainer.new()
    _settings_box.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _settings_box.visible = false
    var panel := SettingsPanel.new()
    panel.closed.connect(_show_menu)
    _settings_box.add_child(panel)
    add_child(_settings_box)


func _button(parent: Control, text: String, cb: Callable) -> void:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = Vector2(0, 76)
    b.pressed.connect(cb)
    parent.add_child(b)


func _show_settings() -> void:
    _menu_box.visible = false
    _settings_box.visible = true


func _show_menu() -> void:
    _settings_box.visible = false
    _menu_box.visible = true
