extends Node3D
## Phase 1 game scene: builds the world, player, UI and a pooled zombie spawner.

const WorldBuilder = preload("res://scripts/world/world_builder.gd")
const Player = preload("res://scripts/player/player.gd")
const Zombie = preload("res://scripts/zombies/zombie.gd")
const Hud = preload("res://scripts/ui/hud.gd")
const TouchControls = preload("res://scripts/ui/touch_controls.gd")
const PauseMenu = preload("res://scripts/ui/pause_menu.gd")

const MAX_ZOMBIES := 14
const SPAWN_MIN := 24.0
const SPAWN_MAX := 45.0
const DESPAWN_DIST := 80.0

var world = null
var player = null
var env: Environment
var sun: DirectionalLight3D
var hud = null
var touch = null
var pause_menu = null

var _pool: Array = []
var _spawn_timer := 1.0
var _kills := 0


func _ready() -> void:
    randomize()
    _setup_environment()
    world = WorldBuilder.new()
    add_child(world)
    world.build()
    player = Player.new()
    player.position = Vector3(0.0, 0.1, 0.0)
    add_child(player)
    _setup_ui()
    _setup_zombies()
    Settings.changed.connect(_apply_settings)
    _apply_settings()
    for i in 6:
        _spawn_one(14.0, 30.0)


# ---------------------------------------------------------------- environment
func _setup_environment() -> void:
    env = Environment.new()
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color(0.36, 0.43, 0.52)
    sky_mat.sky_horizon_color = Color(0.64, 0.67, 0.7)
    sky_mat.ground_horizon_color = Color(0.64, 0.67, 0.7)
    sky_mat.ground_bottom_color = Color(0.25, 0.27, 0.28)
    var sky := Sky.new()
    sky.sky_material = sky_mat
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.fog_light_color = Color(0.64, 0.67, 0.7)
    env.fog_sky_affect = 0.0
    env.glow_intensity = 0.5
    env.glow_bloom = 0.05
    env.adjustment_enabled = true
    env.adjustment_saturation = 0.85
    var we := WorldEnvironment.new()
    we.environment = env
    add_child(we)

    sun = DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-52.0, 30.0, 0.0)
    sun.light_color = Color(1.0, 0.96, 0.88)
    sun.light_energy = 1.1
    sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
    add_child(sun)


func _apply_settings() -> void:
    Settings.apply_world(env, sun, player.camera)


# ---------------------------------------------------------------- UI wiring
func _setup_ui() -> void:
    hud = Hud.new()
    add_child(hud)
    var layer := CanvasLayer.new()
    layer.layer = 5
    add_child(layer)
    touch = TouchControls.new()
    layer.add_child(touch)
    pause_menu = PauseMenu.new()
    add_child(pause_menu)

    player.touch = touch
    hud.bind(player)
    touch.attack_pressed.connect(player.attack)
    touch.jump_pressed.connect(player.queue_jump)
    touch.pause_pressed.connect(_open_pause)
    player.died.connect(_on_player_died)
    pause_menu.resume_pressed.connect(_resume)
    pause_menu.restart_pressed.connect(_restart)
    pause_menu.menu_pressed.connect(_to_menu)


func _open_pause() -> void:
    if get_tree().paused:
        return
    touch.reset()
    pause_menu.open("PAUSED", true)
    get_tree().paused = true


func _resume() -> void:
    pause_menu.close()
    get_tree().paused = false


func _restart() -> void:
    get_tree().paused = false
    get_tree().reload_current_scene()


func _to_menu() -> void:
    get_tree().paused = false
    get_tree().change_scene_to_file("res://scenes/main_menu.tscn")


func _on_player_died() -> void:
    await get_tree().create_timer(1.8).timeout
    touch.reset()
    pause_menu.open("YOU DIED", false)
    get_tree().paused = true


func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
        _open_pause()


func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_GO_BACK_REQUEST or what == NOTIFICATION_APPLICATION_PAUSED:
        if touch != null and player != null and not player.stats.dead:
            _open_pause()


# ---------------------------------------------------------------- zombies
func _setup_zombies() -> void:
    var holder := Node3D.new()
    holder.name = "Zombies"
    add_child(holder)
    for i in MAX_ZOMBIES:
        var z = Zombie.new()
        holder.add_child(z)
        z.killed.connect(_on_zombie_killed)
        _pool.append(z)


func _on_zombie_killed() -> void:
    _kills += 1
    hud.kills = _kills


func _in_building(p: Vector3) -> bool:
    for r in world.building_rects:
        if r.has_point(Vector2(p.x, p.z)):
            return true
    return false


func _spawn_one(min_d: float, max_d: float) -> bool:
    var z = null
    for c in _pool:
        if not c.active:
            z = c
            break
    if z == null:
        return false
    var pp: Vector3 = player.global_position
    for i in 16:
        var a := randf() * TAU
        var d := randf_range(min_d, max_d)
        var p := pp + Vector3(cos(a), 0.0, sin(a)) * d
        if absf(p.x) > WorldBuilder.HALF - 4.0 or absf(p.z) > WorldBuilder.HALF - 4.0:
            continue
        if _in_building(p):
            continue
        p.y = 0.15
        z.activate(p, player)
        return true
    return false


func _alive_count() -> int:
    var n := 0
    for z in _pool:
        if z.active and z.is_alive():
            n += 1
    return n


func _process(delta: float) -> void:
    var pp: Vector3 = player.global_position
    for z in _pool:
        if z.active and z.is_alive() and z.global_position.distance_to(pp) > DESPAWN_DIST:
            z.deactivate()
    _spawn_timer -= delta
    if _spawn_timer <= 0.0:
        _spawn_timer = 2.5
        if _alive_count() < MAX_ZOMBIES - 2:
            _spawn_one(SPAWN_MIN, SPAWN_MAX)
