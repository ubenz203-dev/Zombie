# Dead Horizon (working title)

First-person open-world zombie survival game for Android. Godot 4.3 (Mobile renderer), GDScript.

## Build the APK (GitHub Actions)
1. Push this folder to a GitHub repo (root of the repo = this folder).
2. Actions tab -> "Android APK (debug)" runs on push, or use "Run workflow".
3. Open the finished run -> Artifacts -> `deadhorizon-debug-apk` -> unzip -> install `deadhorizon-debug.apk`.
   `build-logs` is always uploaded (import / smoke test / export logs).

## Run on desktop (quick test)
Open the folder in Godot 4.3 and press F5.
WASD move, Shift sprint, Space jump, F attack, right-mouse-drag look, Esc pause.

## Layout
- `scripts/settings.gd` - graphics presets, ConfigFile persistence (autoload `Settings`)
- `scripts/player/` - first-person controller, survival stats
- `scripts/zombies/zombie.gd` - pooled zombie AI
- `scripts/world/world_builder.gd` - procedural test town
- `scripts/ui/` - HUD, touch controls, menus, settings panel
- `tests/smoke_test.gd` - headless smoke test used by CI
